# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch

import flag_gems

from . import base, consts, utils


def log_softmax_input_fn(shape, dtype, device):
    # torch._log_softmax takes (self, dim, half_to_float) positionally, so the
    # reduction dim and the half_to_float flag have to be supplied here rather
    # than relying on the generic unary input function.
    inp = utils.generate_tensor_input(shape, dtype, device)
    dim = 1 if len(shape) > 1 else 0
    yield inp, dim, False


def log_softmax_out_input_fn(shape, dtype, device):
    inp = utils.generate_tensor_input(shape, dtype, device)
    out = torch.empty_like(inp)
    if len(shape) > 1:
        yield inp, 1, False, {"out": out}
    else:
        yield inp, 0, False, {"out": out}


@pytest.mark.log_softmax
@pytest.mark.skipif(
    flag_gems.vendor_name == "tsingmicro", reason="Issue #4131: not working"
)
def test_log_softmax():
    bench = base.GenericBenchmark2DOnly(
        op_name="log_softmax",
        input_fn=log_softmax_input_fn,
        torch_op=torch._log_softmax,
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()


@pytest.mark.log_softmax_out
@pytest.mark.skipif(
    flag_gems.vendor_name == "tsingmicro", reason="Issue #4131: not working"
)
def test_log_softmax_out():
    bench = base.GenericBenchmarkExcluse1D(
        op_name="log_softmax_out",
        input_fn=log_softmax_out_input_fn,
        torch_op=torch._log_softmax,
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()


@pytest.mark.log_softmax_backward_data
@pytest.mark.skipif(
    flag_gems.vendor_name == "tsingmicro", reason="Issue #4131: not working"
)
def test_log_softmax_backward_data():
    def log_softmax_backward_data_case_fn(shape, cur_dtype):
        yield base.BenchmarkCasePlan(
            shape={"input": list(shape)},
            builder_args=(shape,),
        )

    def log_softmax_backward_data_build_inputs_fn(plan, cur_dtype, device):
        (shape,) = plan.builder_args
        inp = torch.randn(shape, dtype=cur_dtype, device=device)
        output = torch._log_softmax(inp, dim=-1, half_to_float=False)
        grad_output = torch.randn_like(output)
        return grad_output, output, -1, cur_dtype

    bench = base.GenericBenchmark2DOnly(
        op_name="log_softmax_backward_data",
        case_fn=log_softmax_backward_data_case_fn,
        build_inputs_fn=log_softmax_backward_data_build_inputs_fn,
        torch_op=torch._log_softmax_backward_data,
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()


def log_softmax_backward_data_out_input_fn(shape, dtype, device):
    inp = torch.randn(shape, dtype=dtype, device=device)
    log_sm = torch._log_softmax(inp, dim=-1, half_to_float=False)
    grad_output = torch.randn_like(log_sm)
    out = torch.empty_like(grad_output)
    yield grad_output, log_sm, -1, dtype, {"out": out}


@pytest.mark.log_softmax_backward_data_out
@pytest.mark.skipif(
    flag_gems.vendor_name == "tsingmicro", reason="Issue #4131: not working"
)
def test_log_softmax_backward_data_out():
    bench = base.GenericBenchmark2DOnly(
        op_name="log_softmax_backward_data_out",
        input_fn=log_softmax_backward_data_out_input_fn,
        torch_op=torch._log_softmax_backward_data,
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()
