# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch

from . import base, consts

LIST_LENGTH = 8


def _case_fn(shape, dtype):
    del dtype
    dims = tuple(shape)
    yield base.BenchmarkCasePlan(
        shape={"tensors": [list(dims)] * LIST_LENGTH},
        params={"overload": "List"},
        builder_args=(dims,),
    )


def _build_inputs_fn(plan, dtype, device):
    (shape,) = plan.builder_args
    torch.manual_seed(0)

    def make_list():
        return [
            torch.rand(shape, dtype=dtype, device=device) + 1.0
            for _ in range(LIST_LENGTH)
        ]

    self_tensors = make_list()
    tensors1 = make_list()
    weight = make_list()
    return self_tensors, tensors1, weight


@pytest.mark.foreach_lerp_list
def test_foreach_lerp_list():
    bench = base.GenericBenchmark(
        op_name="foreach_lerp_list",
        torch_op=torch.ops.aten._foreach_lerp.List,
        case_fn=_case_fn,
        build_inputs_fn=_build_inputs_fn,
        dtypes=consts.FLOAT_DTYPES,
    )
    bench.run()
