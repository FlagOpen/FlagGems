# Copyright 2026 FlagOS Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
import torch

from . import base, consts
from .generated_operator_utils import OperatorBenchmark


_ATEN_OP = torch.ops.aten._foreach_neg_
_LIST_LENGTHS = (1, 16)


def _case_fn(shape, dtype):
    del dtype
    dims = tuple(shape)
    for length in _LIST_LENGTHS:
        yield base.BenchmarkCasePlan(
            shape={"self": [list(dims)] * length},
            params={"list_length": length},
            builder_args=(dims, length),
        )


def _build_inputs_fn(plan, dtype, device):
    shape, length = plan.builder_args
    torch.manual_seed(0)
    values = [
        torch.rand(shape, dtype=dtype, device=device).mul_(0.8).add_(0.1)
        for _ in range(length)
    ]
    return (values,)


@pytest.mark.foreach_neg_
def test_foreach_neg__benchmark():
    bench = OperatorBenchmark(
        op_name="foreach_neg_",
        torch_op=_ATEN_OP,
        case_fn=_case_fn,
        build_inputs_fn=_build_inputs_fn,
        dtypes=consts.FLOAT_DTYPES,
        is_inplace=True,
        fresh_inputs=True,
    )
    bench.run()
