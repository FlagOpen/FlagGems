# 未完全注入 pytest 汇总

共 374 个平台/算子任务，去重后 155 个算子名称。来源是两批审核及 OOM 专项合并后的最新失败结论；每个平台/算子只取一条。这里只收集“未完全注入”，不包含 reference 失败或执行异常。

task_index.csv 可按平台和算子筛选；manifest.json 保存源码版本、pytest marker、正确性文件、配套 benchmark 和失败报告之间的精确映射。evidence/ 是每项原始注入探针诊断，REACHED/BYPASSED/PRE_CALL_ERROR/SKIP 等含义保持原样；“未完全注入”是统一分类，不代表每个问题都已确认属于同一种根因。

sources/aaf9d8db/ 对应原实验冻结 Gems；sources/c38a360e/ 对应最近修复后的 kernelgen-dev。不同 commit 的文件分别保存，没有用最新源码替换旧失败现场。primary correctness 文件按 commit/path 去重；同一个文件可能覆盖多个算子和多个平台。少数报告因未进入 pytest call 而没有 nodeid，使用同版本 KGS suite discovery 规则补齐原 pytest 文件。

包含对应 correctness pytest、benchmark 及递归解析得到的本地 helper/conftest 和 benchmark YAML。没有复制完整 Gems 实现、运行时或环境凭据。此 ZIP 是源码审阅/修复包，不是独立安装包；复现时使用 manifest 指定的 Gems checkout 和目标平台运行时，在其上核对这些文件，再按 marker 执行。多个 marker 的文件应只执行任务对应的 marker。

例：pytest tests/test_foreach_abs.py -m foreach_abs --override foreach_abs:/path/to/candidate.py:run

checksums.sha256 校验所有归档成员。平台计数：{"ascend-8": 44, "hygon": 103, "metax": 81, "musa": 89, "ppu": 57}。
